{
	press_items: [
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			name: 'Small \'E\' in hexagon',
			filetype: 'png'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439682_logo.svg',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439978_ky0mjwht2rkvyj5rk9.png',
			name: 'Full enduro logo',
			filetype: 'svg'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484646517_built_with_enduro.svg',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484646509_pprb9gm7y7eczui9kke29.png',
			name: 'Built with enduro.js',
			filetype: 'svg'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484647422_made_with_enduro.psd',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484647476_k6ludni09zelcpiudi.png',
			name: 'Built with enduro.js',
			filetype: 'psd'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484647615_made_with_enduro.png',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484647635_o1jtlsej2wdo83hyw4s4i.png',
			name: 'Built with enduro.js',
			filetype: 'png'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484647617_made_with_enduro@2x.png',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1484647639_hj27cysfnyr37jw3tyb9.png',
			name: 'Built with enduro.js - retina',
			filetype: 'png'
		}
	],
	meta: {
		last_edited: 1501680325
	}
}