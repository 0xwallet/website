{
	mainmenu: {
		items: [
			{
				label: 'Home',
				link: '/',
				new_window: false
			},
			{
				label: 'Themes',
				link: '/themes',
				new_window: false
			},
			{
				label: 'Documentation',
				link: '/docs',
				new_window: false
			},
			{
				label: 'Blog',
				link: '/blog',
				new_window: false
			},
			{
				label: 'Demo',
				link: 'http://demo.endurojs.com/admin',
				new_window: true
			}
		]
	},
	meta: {
		last_edited: 1501680325
	}
}