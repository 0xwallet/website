{
	$background_video_type: 'video',
	background_video: 'https://d32ujqjov16ho0.cloudfront.net/direct_uploads/1473692861_Skyline.mp4',
	$background_video_poster_type: 'image',
	background_video_poster: 'https://d32ujqjov16ho0.cloudfront.net/direct_uploads/1473748977_videobg.jpg',
	heading: 'Enduro.js',
	tagline: 'Minimalistic, lean & mean, node.js cms',
	features_heading: 'Why enduro?',
	meta: {
		last_edited: 1501680325
	}
}