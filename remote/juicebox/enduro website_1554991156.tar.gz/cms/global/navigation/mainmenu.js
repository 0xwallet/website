({
	mainmenu: {
		items: [
			{
				label: 'Home',
				link: '/',
				new_window: false,
				$label_cn: '主页',
				$link_cn: '/cn'
			},
			{
				label: 'Docs',
				link: '/docs',
				new_window: false,
				$label_cn: '文档',
				$link_cn: '/docs'
			},
			{
				label: 'Blog',
				link: '/blog',
				new_window: false,
				$label_cn: '博客',
				$link_cn: '/blog'
			},
			{
				label: 'Log In',
				link: 'https://owaf.io/login',
				new_window: true,
				$label_cn: '登录',
				$link_cn: 'https://owaf.io/login'
			}
		]
	},
	meta: {
		last_edited: 1554916194
	}
})
