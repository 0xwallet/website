({
	$documentation_list_size: 12,
	documentation_list: [
		{
			label: 'Understanding 0xWallet',
			topics: [
				{
					label: 'What is 0xWallet'
				},
				{
					label: '0xWallet for Business'
				},
				{
					label: '0xWallet Card'
				}
			],
			$label_cn: '了解 0xWallet'
		},
		{
			label: 'Getting started',
			topics: [
				{
					label: 'Hello world'
				},
				{
					label: 'Templates'
				},
				{
					label: 'Content files'
				}
			]
		},
		{
			label: 'Using 0xWallet',
			topics: [
				{
					label: 'Cli'
				},
				{
					label: 'App'
				},
				{
					label: 'Ab testing'
				},
				{
					label: 'Juicebox'
				},
				{
					label: 'Generators'
				}
			]
		},
		{
			label: 'Build tools',
			topics: [
				{
					label: 'Sass'
				},
				{
					label: 'Iconfont generator'
				},
				{
					label: 'Spritesheet generator'
				}
			]
		},
		{
			label: 'Advanced features',
			topics: [
				{
					label: 'Abstractors'
				},
				{
					label: 'Globalizer'
				},
				{
					label: 'Templatitator'
				},
				{
					label: 'Multilingual support'
				},
				{
					label: 'Linker'
				},
				{
					label: 'Trollhunter'
				}
			]
		},
		{
			label: 'Admin interface',
			topics: [
				{
					label: 'Introduction to admin'
				},
				{
					label: 'Termination'
				},
				{
					label: 'List of admin control types'
				}
			]
		},
		{
			label: 'Deployment',
			topics: [
				{
					label: 'Heroku'
				},
				{
					label: 'Static pages'
				},
				{
					label: 'Netlify'
				}
			]
		},
		{
			label: 'Admin controls',
			topics: [
				{
					label: 'Object control type'
				}
			]
		},
		{
			label: 'Built-in helpers',
			topics: [
				{
					label: 'Grouped each'
				}
			]
		},
		{
			label: 'Enduro\'s libraries',
			topics: [
				{
					label: 'temper'
				}
			]
		},
		{
			label: 'Misc',
			topics: [
				{
					label: 'Made with enduro'
				}
			]
		},
		{
			label: 'Enduro bricks',
			topics: [
				{
					label: 'Enduro bricks'
				},
				{
					label: 'Context modifiers'
				},
				{
					label: 'Brick processors'
				}
			]
		}
	],
	meta: {
		last_edited: 1554916411
	}
})