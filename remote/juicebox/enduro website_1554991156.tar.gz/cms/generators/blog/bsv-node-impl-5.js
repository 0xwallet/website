({
	title: 'BSV节点实现日志（5）',
	$date_value: '2019-04-08',
	$date_type: 'date',
	date: 'Monday, 08 April, 2019',
	published: true,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '# headers\nheaders 信息是对 getheaders 的回复，内容包含多个区块头。对于区块头，在0.1.1版本的代码中，是这样解释的：\n```\n// Nodes collect new transactions into a block, hash them into a hash tree,\n// and scan through nonce values to make the block\'s hash satisfy proof-of-work\n// requirements.  When they solve the proof-of-work, they broadcast the block\n// to everyone and the block is added to the block chain.  The first transaction\n// in the block is a special one that creates a new coin owned by the creator\n// of the block.\n```\n\n> 节点将新的交易收集到一个区块中，把它们哈希到一个哈希树里，然后选择nonce值使得区块的哈希能够满足工作量证明的要求。当他们解决了工作量证明，他们将区块广播到所有人，然后区块被添加到区块链。区块中的第一笔交易是特殊的，它创造了属于这个区块的制造者的新的比特币。\n\n\nheader的解构中比较特殊的一点就是 version 使用的是有符号数。另外，在 headers 消息中，所有header的 tx_count 都是0 。\n\n👇是解析bsv节点发来的 headers 信息后，得到的其中一个header。\n```erlang\n				 #{bits =>\n             <<0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0>>,\n         merkel_root =>\n             <<234,191,33,94,12,197,38,255,152,2,254,22,113,125,254,135,215,52,\n               188,144,187,234,221,188,214,26,8,49,230,114,240,16>>,\n         nonce => <<0,53,206,178>>,\n         prev_block =>\n             <<38,162,46,60,45,25,212,154,28,28,184,166,142,106,183,116,64,195,\n               14,89,116,64,74,42,128,109,73,161,0,0,0,0>>,\n         timestamp => 1233046715,tx_count => 0,version => 1}\n```\n\n其中的 bits 字段代表的是工作量证明的要求，区块两次哈希之后并翻转后的值，需要小于这个要求。\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554965776930-a0c4a1ac-b8b3-41ba-a913-60f81eb9b23e.png#align=left&display=inline&height=479&name=image.png&originHeight=958&originWidth=786&size=966497&status=done&width=393)\n\n在收到区块的哈希之后，可以先检查其是否满足pow的难度要求：\n```erlang\nvalid_pow(Hash, Target) ->\n    rev(Hash) < Target.\n```\n\n现在我们已经有了许多从创世区块开始的区块头，有必要以合适的数据解构将它们存储起来。',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<h1 id="headers">headers</h1>\n<p>headers 信息是对 getheaders 的回复，内容包含多个区块头。对于区块头，在0.1.1版本的代码中，是这样解释的：</p>\n<pre><code>// Nodes collect new transactions into a block, hash them into a hash tree,\n// and scan through nonce values to make the block&#39;s hash satisfy proof-of-work\n// requirements.  When they solve the proof-of-work, they broadcast the block\n// to everyone and the block is added to the block chain.  The first transaction\n// in the block is a special one that creates a new coin owned by the creator\n// of the block.\n</code></pre><blockquote>\n<p>节点将新的交易收集到一个区块中，把它们哈希到一个哈希树里，然后选择nonce值使得区块的哈希能够满足工作量证明的要求。当他们解决了工作量证明，他们将区块广播到所有人，然后区块被添加到区块链。区块中的第一笔交易是特殊的，它创造了属于这个区块的制造者的新的比特币。</p>\n</blockquote>\n<p>header的解构中比较特殊的一点就是 version 使用的是有符号数。另外，在 headers 消息中，所有header的 tx_count 都是0 。</p>\n<p>👇是解析bsv节点发来的 headers 信息后，得到的其中一个header。</p>\n<pre><code class="lang-erlang">                 #{bits =&gt;\n             &lt;&lt;0,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0&gt;&gt;,\n         merkel_root =&gt;\n             &lt;&lt;234,191,33,94,12,197,38,255,152,2,254,22,113,125,254,135,215,52,\n               188,144,187,234,221,188,214,26,8,49,230,114,240,16&gt;&gt;,\n         nonce =&gt; &lt;&lt;0,53,206,178&gt;&gt;,\n         prev_block =&gt;\n             &lt;&lt;38,162,46,60,45,25,212,154,28,28,184,166,142,106,183,116,64,195,\n               14,89,116,64,74,42,128,109,73,161,0,0,0,0&gt;&gt;,\n         timestamp =&gt; 1233046715,tx_count =&gt; 0,version =&gt; 1}\n</code></pre>\n<p>其中的 bits 字段代表的是工作量证明的要求，区块两次哈希之后并翻转后的值，需要小于这个要求。\n<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554965776930-a0c4a1ac-b8b3-41ba-a913-60f81eb9b23e.png#align=left&amp;display=inline&amp;height=479&amp;name=image.png&amp;originHeight=958&amp;originWidth=786&amp;size=966497&amp;status=done&amp;width=393" alt="image.png"></p>\n<p>在收到区块的哈希之后，可以先检查其是否满足pow的难度要求：</p>\n<pre><code class="lang-erlang">valid_pow(Hash, Target) -&gt;\n    rev(Hash) &lt; Target.\n</code></pre>\n<p>现在我们已经有了许多从创世区块开始的区块头，有必要以合适的数据解构将它们存储起来。</p>\n',
		contents: [
			{
				heading: 'headers',
				level: '1',
				link: 'headers'
			}
		]
	},
	teaser: {
		doc: 'Nodes collect new transactions into a block, hash them into a hash tree, and scan through nonce values to make the block\'s hash satisfy proof-of-work requirements. When they solve the proof-of-work, they broadcast the block to everyone and the block is added to the block chain.  The first transaction in the block is a special one that creates a new coin owned by the creator of the block.',
		$image_type: 'image',
		image: '/remote/direct_uploads/1554987980_image.png',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '<p>Nodes collect new transactions into a block, hash them into a hash tree, and scan through nonce values to make the block&#39;s hash satisfy proof-of-work requirements. When they solve the proof-of-work, they broadcast the block to everyone and the block is added to the block chain.  The first transaction in the block is a special one that creates a new coin owned by the creator of the block.</p>\n',
			contents: []
		}
	},
	meta: {
		last_edited: 1554991039
	}
})