({
	title: 'bit:// 协议',
	$date_value: '2019-04-09',
	$date_type: 'date',
	date: 'Tuesday, 09 April, 2019',
	published: true,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '# 通用URI模板\n\nbsv目前已经有了 b://, c:// 这样的协议，今后还会有更多各种各样的协议，所以迫切地需要一个通用的协议，俗称协议的协议。\n\n目前对于bsv 应用的协议的定义一般是：根据txid找到链上数据，这是原料，然后根据这个协议的内容对原料进行处理，最后得到用户可使用的产品。例如 b:// 协议，放进去的是txid，得出来的可能是bitstagram上的图片等文件。<br />![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554903316337-20ab4343-bead-477a-b20a-88e623ed679f.png#align=left&display=inline&height=243&name=image.png&originHeight=976&originWidth=2006&size=561279&status=done&width=500)\n\n在前段时间，_unwriter 已经发布了用于注册协议 ID 的 bitcom 项目。受到比特币地址的防碰撞机制的启发（世界上没有两个人能够在安全隔离的环境下，生成出相同的比特币地址），_unwriter 采用比特币地址作为协议的 ID。\n\n所以，bit:// 的第一部分就是bsv应用协议的ID, 即一个比特币地址。\n```\nbit://[B: Bitcom Address]/[Transaction ID]\n```\n\n后面的部分的格式，是由该协议的管理者来决定的。管理者可以将协议的定义文档发送到链上。比如一个协议想要支持 user， tx 这两个参数输入，就可以使用协议 ID 的地址发送以下内容到链上：\n```\nOP_RETURN $ route enable /user/:user\nOP_RETURN $ route enable /tx/:tx\n```\n\n\n<a name="12ab1955"></a>\n# 分布式路由\n\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554900493175-e8ca2f9b-4a91-4de9-9615-94bf7fb6b9fd.png#align=left&display=inline&height=183&name=image.png&originHeight=578&originWidth=1578&size=1056107&status=done&width=500)\n\n熟悉bsv的朋友们可能听说过瓶子浏览器，通过连接到支持 b:// 协议服务的 API，就可以浏览各种的链上文件、图片等资源。这些API服务商，例如 bico.media 等等，通常会有一个自己运行的 BitDB 服务器。\n\n这种模式的问题在于，用户需要在自己的瓶子浏览器里配置 API 的地址，虽然瓶子浏览器可以内置地址，但这样不便于更新，也有中心化的问题。既然我们已经有了bsv链这个能够保证数据的最终一致性的共识层，那么为什么不把这些 API 配置保存到链上呢？所以，在 bit:// 协议中，用户可以从链上获取到 API 服务商的 route mapping。<br />![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554901205832-f7740065-3495-4eb6-8d4f-f59c088032e6.png#align=left&display=inline&height=272&name=image.png&originHeight=762&originWidth=1402&size=1218522&status=done&width=500)\n\n这样，在用户初次安装瓶子浏览器的时候，只需要使用内置的 API 服务，这一点和比特币节点的启动机制如出一辙。然后，再去请求链上的最新的 route mapping，并保存到本地。之后，瓶子浏览器就可以根据各个 API 的速度来进行选择。\n\n最重要的是，比特币是共识层而非存储层，矿工没有激励去存储完整的区块信息。这时候，对于一些开放的协议，例如 b://, c:// 这种的公开文件协议，要保证数据的持久可用，就需要始终能够连接到正常运行的API服务。借助于bit://  协议的分布式路由机制，我们可以获得到世界上所有支持某个特定协议的 API 服务商，进而得到我们想要的数据。\n\n任何人都可以发送针对于某个协议的 API 服务的 route 到链上，例如：\n```\nOP_RETURN $ route add 19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut /:tx https://bico.media/${tx}\nOP_RETURN $ route add 19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut /:tx https://api.bitpaste.app/${tx}/raw\nOP_RETURN $ route add 19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut /:tx https://media.bitcoinfiles.org/${tx}\n```\n\n那么，如何保证这个API是真实可用的？如果有人发送了一个虚假的route到链上，例如调换了两个参数的输入位置，访问的结果可能依旧是可用的，但是数据是错误的。所以，我们在使用时需要能够保证 route 记录是由 API 服务商亲自发出的。\n\n_unwriter 前几天发布的 bitsticker 协议能够完美解决这个问题。在API调用返回的HTTP Header 中，嵌入发布 route 记录所使用的比特币地址即可。\n```\nHTTP/1.1 200 OK\nserver: nginx/1.15.5 (Ubuntu)\ndate: Sun, 31 Mar 2019 19:21:05 GMT\'\ncontent-type: image/jpeg\ncontent-length: 90887\nconnection: close\nx-powered-by: Express\naccess-control-allow-origin: *\nbitcoin-address: 1ApeFekX4JJLxiK991KHkTSJe9zFTunNHx\n```\n\n\n更多的自动化，更多的安全，更美好的未来。',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<h1 id="-uri-">通用URI模板</h1>\n<p>bsv目前已经有了 b://, c:// 这样的协议，今后还会有更多各种各样的协议，所以迫切地需要一个通用的协议，俗称协议的协议。</p>\n<p>目前对于bsv 应用的协议的定义一般是：根据txid找到链上数据，这是原料，然后根据这个协议的内容对原料进行处理，最后得到用户可使用的产品。例如 b:// 协议，放进去的是txid，得出来的可能是bitstagram上的图片等文件。&lt;br /&gt;<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554903316337-20ab4343-bead-477a-b20a-88e623ed679f.png#align=left&amp;display=inline&amp;height=243&amp;name=image.png&amp;originHeight=976&amp;originWidth=2006&amp;size=561279&amp;status=done&amp;width=500" alt="image.png"></p>\n<p>在前段时间，_unwriter 已经发布了用于注册协议 ID 的 bitcom 项目。受到比特币地址的防碰撞机制的启发（世界上没有两个人能够在安全隔离的环境下，生成出相同的比特币地址），_unwriter 采用比特币地址作为协议的 ID。</p>\n<p>所以，bit:// 的第一部分就是bsv应用协议的ID, 即一个比特币地址。</p>\n<pre><code>bit://[B: Bitcom Address]/[Transaction ID]\n</code></pre><p>后面的部分的格式，是由该协议的管理者来决定的。管理者可以将协议的定义文档发送到链上。比如一个协议想要支持 user， tx 这两个参数输入，就可以使用协议 ID 的地址发送以下内容到链上：</p>\n<pre><code>OP_RETURN $ route enable /user/:user\nOP_RETURN $ route enable /tx/:tx\n</code></pre><p>&lt;a name=&quot;12ab1955&quot;&gt;&lt;/a&gt;</p>\n<h1 id="-">分布式路由</h1>\n<p><img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554900493175-e8ca2f9b-4a91-4de9-9615-94bf7fb6b9fd.png#align=left&amp;display=inline&amp;height=183&amp;name=image.png&amp;originHeight=578&amp;originWidth=1578&amp;size=1056107&amp;status=done&amp;width=500" alt="image.png"></p>\n<p>熟悉bsv的朋友们可能听说过瓶子浏览器，通过连接到支持 b:// 协议服务的 API，就可以浏览各种的链上文件、图片等资源。这些API服务商，例如 bico.media 等等，通常会有一个自己运行的 BitDB 服务器。</p>\n<p>这种模式的问题在于，用户需要在自己的瓶子浏览器里配置 API 的地址，虽然瓶子浏览器可以内置地址，但这样不便于更新，也有中心化的问题。既然我们已经有了bsv链这个能够保证数据的最终一致性的共识层，那么为什么不把这些 API 配置保存到链上呢？所以，在 bit:// 协议中，用户可以从链上获取到 API 服务商的 route mapping。&lt;br /&gt;<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554901205832-f7740065-3495-4eb6-8d4f-f59c088032e6.png#align=left&amp;display=inline&amp;height=272&amp;name=image.png&amp;originHeight=762&amp;originWidth=1402&amp;size=1218522&amp;status=done&amp;width=500" alt="image.png"></p>\n<p>这样，在用户初次安装瓶子浏览器的时候，只需要使用内置的 API 服务，这一点和比特币节点的启动机制如出一辙。然后，再去请求链上的最新的 route mapping，并保存到本地。之后，瓶子浏览器就可以根据各个 API 的速度来进行选择。</p>\n<p>最重要的是，比特币是共识层而非存储层，矿工没有激励去存储完整的区块信息。这时候，对于一些开放的协议，例如 b://, c:// 这种的公开文件协议，要保证数据的持久可用，就需要始终能够连接到正常运行的API服务。借助于bit://  协议的分布式路由机制，我们可以获得到世界上所有支持某个特定协议的 API 服务商，进而得到我们想要的数据。</p>\n<p>任何人都可以发送针对于某个协议的 API 服务的 route 到链上，例如：</p>\n<pre><code>OP_RETURN $ route add 19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut /:tx https://bico.media/${tx}\nOP_RETURN $ route add 19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut /:tx https://api.bitpaste.app/${tx}/raw\nOP_RETURN $ route add 19HxigV4QyBv3tHpQVcUEQyq1pzZVdoAut /:tx https://media.bitcoinfiles.org/${tx}\n</code></pre><p>那么，如何保证这个API是真实可用的？如果有人发送了一个虚假的route到链上，例如调换了两个参数的输入位置，访问的结果可能依旧是可用的，但是数据是错误的。所以，我们在使用时需要能够保证 route 记录是由 API 服务商亲自发出的。</p>\n<p>_unwriter 前几天发布的 bitsticker 协议能够完美解决这个问题。在API调用返回的HTTP Header 中，嵌入发布 route 记录所使用的比特币地址即可。</p>\n<pre><code>HTTP/1.1 200 OK\nserver: nginx/1.15.5 (Ubuntu)\ndate: Sun, 31 Mar 2019 19:21:05 GMT&#39;\ncontent-type: image/jpeg\ncontent-length: 90887\nconnection: close\nx-powered-by: Express\naccess-control-allow-origin: *\nbitcoin-address: 1ApeFekX4JJLxiK991KHkTSJe9zFTunNHx\n</code></pre><p>更多的自动化，更多的安全，更美好的未来。</p>\n',
		contents: [
			{
				heading: '通用URI模板',
				level: '1',
				link: '-uri-'
			},
			{
				heading: '分布式路由',
				level: '1',
				link: '-'
			}
		]
	},
	teaser: {
		doc: '昨天（2019.4.9）bsv应用开发界的牛人_unwriter 发布了 一个新的协议，名为bit:// 。据介绍该协议被称为协议的协议，可以解决比特币应用开发和使用中的诸多问题。',
		$image_type: 'image',
		image: '/remote/direct_uploads/1554918694_image.png',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '<p>昨天（2019.4.9）bsv应用开发界的牛人_unwriter 发布了 一个新的协议，名为bit:// 。据介绍该协议被称为协议的协议，可以解决比特币应用开发和使用中的诸多问题。</p>\n',
			contents: []
		}
	},
	meta: {
		last_edited: 1554991061
	}
})