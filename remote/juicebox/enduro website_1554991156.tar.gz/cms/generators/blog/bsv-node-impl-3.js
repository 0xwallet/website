({
	title: 'BSV节点实现日志（3）',
	$date_value: '2019-04-03',
	$date_type: 'date',
	date: 'Wednesday, 03 April, 2019',
	published: false,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '> ©️OWAF\n\n# verack\n\n在2010年五月，bitcoin的代码更新到了 [0.2.9版本](https://github.com/bitcoin-sv/bitcoin-sv/commit/42605ce8bcc9bd01b86491c74fee14de77960868) ，其中将protocol version也升级到了209，添加了verack指令，用于回复收到的verion指令。\n\n与节点连接后，首先进行的对话：<br />![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554786359220-fea92faf-065d-4f72-bbc2-17d2d6da4f50.png#align=left&display=inline&height=258&name=image.png&originHeight=598&originWidth=1160&size=852438&status=done&width=500)\n\n```erlang\n%% verack 只是用来告知对方，自己已经收到version\nhandle_command("version", _Payload, Socket) ->\n    send_message(Socket, verack_msg());\n```\n\n\n# ping & pong\n\n2009,11,13，比特币代码中加入了 [ping 和 pong 指令](https://github.com/bitcoin-sv/bitcoin-sv/commit/70e79525c97c33a5fca8674d47d86cc2b7ae197a#diff-118fcbaaba162ba17933c7893247df3aR2197) ，用于确认远程节点是否还在运行。最初的间隔时间是12分钟无消息来往，就发送一个ping，现在bsv节点中的配置是2分钟。\n\n实现了verack,ping,pong指令，让我们再试着连接到bsv节点：<br />\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554796869821-11ba90fa-ce5f-4250-a0bd-1e1afdd06d36.png#align=left&display=inline&height=330&name=image.png&originHeight=732&originWidth=1110&size=139302&status=done&width=500)\n\n这里[local] 表示本地发出的指令，[remote]表示远程发来的指令。注意到，远程节点又发来了一个 `getheaders` 指令，这是在请我们对其分享已知的区块数据。明天，我们会解析这条指令中的内容。',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<blockquote>\n<p>©️OWAF</p>\n</blockquote>\n<h1 id="verack">verack</h1>\n<p>在2010年五月，bitcoin的代码更新到了 <a href="https://github.com/bitcoin-sv/bitcoin-sv/commit/42605ce8bcc9bd01b86491c74fee14de77960868">0.2.9版本</a> ，其中将protocol version也升级到了209，添加了verack指令，用于回复收到的verion指令。</p>\n<p>与节点连接后，首先进行的对话：&lt;br /&gt;<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554786359220-fea92faf-065d-4f72-bbc2-17d2d6da4f50.png#align=left&amp;display=inline&amp;height=258&amp;name=image.png&amp;originHeight=598&amp;originWidth=1160&amp;size=852438&amp;status=done&amp;width=500" alt="image.png"></p>\n<pre><code class="lang-erlang">%% verack 只是用来告知对方，自己已经收到version\nhandle_command(&quot;version&quot;, _Payload, Socket) -&gt;\n    send_message(Socket, verack_msg());\n</code></pre>\n<h1 id="ping-pong">ping &amp; pong</h1>\n<p>2009,11,13，比特币代码中加入了 <a href="https://github.com/bitcoin-sv/bitcoin-sv/commit/70e79525c97c33a5fca8674d47d86cc2b7ae197a#diff-118fcbaaba162ba17933c7893247df3aR2197">ping 和 pong 指令</a> ，用于确认远程节点是否还在运行。最初的间隔时间是12分钟无消息来往，就发送一个ping，现在bsv节点中的配置是2分钟。</p>\n<p>实现了verack,ping,pong指令，让我们再试着连接到bsv节点：&lt;br /&gt;\n<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554796869821-11ba90fa-ce5f-4250-a0bd-1e1afdd06d36.png#align=left&amp;display=inline&amp;height=330&amp;name=image.png&amp;originHeight=732&amp;originWidth=1110&amp;size=139302&amp;status=done&amp;width=500" alt="image.png"></p>\n<p>这里[local] 表示本地发出的指令，[remote]表示远程发来的指令。注意到，远程节点又发来了一个 <code>getheaders</code> 指令，这是在请我们对其分享已知的区块数据。明天，我们会解析这条指令中的内容。</p>\n',
		contents: [
			{
				heading: 'verack',
				level: '1',
				link: 'verack'
			},
			{
				heading: 'ping &amp; pong',
				level: '1',
				link: 'ping-pong'
			}
		]
	},
	teaser: {
		doc: '在2010年五月，bitcoin的代码更新到了 0.2.9版本, 其中将protocol version也升级到了209，添加了verack指令，用于回复收到的verion指令。',
		$image_type: 'image',
		image: '',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '<p>在2010年五月，bitcoin的代码更新到了 0.2.9版本, 其中将protocol version也升级到了209，添加了verack指令，用于回复收到的verion指令。</p>\n',
			contents: []
		}
	},
	meta: {
		last_edited: 1554989911
	}
})