({
	title: 'BSV节点实现日志（1）',
	$date_value: '2019-03-31',
	$date_type: 'date',
	date: 'Sunday, 31 March, 2019',
	published: true,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '比特币网络是开放的，理论上一个节点只要符合比特币的共识协议，就可以参与到网络中。为了更深入理解比特币的共识协议，也是为在比特币上做更多的应用打基础，我们决定实现一个简单的可使用的比特币节点，在实现完成后，代码会以MIT协议开源在Github上。\n\n在本篇日志中，我们将通过dns获取到种子节点的列表。\n\n\n# 获取种子节点的IP\n\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554645999973-35f10a84-3e77-40fc-bbe1-4a2813704e53.png#align=left&display=inline&height=241&name=image.png&originHeight=580&originWidth=1204&size=890504&status=done&width=500)\n\n种子节点是新的节点加入比特币网络的引荐人，在节点的代码中会硬编码几个域名。节点在启动时，会向DNS服务器查询这几个域名对应的A记录，便可得到种子节点的IP地址。\n\n```erlang\nseeders() ->\n    ["seed.bitcoinsv.io",\n     "seed.cascharia.com",\n     "seed.satoshisvision.network"\n    ].\n\nseed_nodes() ->\n    L = seeders(),\n    lists:flatten([dnslookup(D) || D <- L]).\n```\n\n运行结果：\n\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554652822504-ee5435ac-efe0-438d-b298-a455d897a173.png#align=left&display=inline&height=283&name=image.png&originHeight=566&originWidth=512&size=81865&status=done&width=256)\n\n\n> ©️OWAF',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<p>比特币网络是开放的，理论上一个节点只要符合比特币的共识协议，就可以参与到网络中。为了更深入理解比特币的共识协议，也是为在比特币上做更多的应用打基础，我们决定实现一个简单的可使用的比特币节点，在实现完成后，代码会以MIT协议开源在Github上。</p>\n<p>在本篇日志中，我们将通过dns获取到种子节点的列表。</p>\n<h1 id="-ip">获取种子节点的IP</h1>\n<p><img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554645999973-35f10a84-3e77-40fc-bbe1-4a2813704e53.png#align=left&amp;display=inline&amp;height=241&amp;name=image.png&amp;originHeight=580&amp;originWidth=1204&amp;size=890504&amp;status=done&amp;width=500" alt="image.png"></p>\n<p>种子节点是新的节点加入比特币网络的引荐人，在节点的代码中会硬编码几个域名。节点在启动时，会向DNS服务器查询这几个域名对应的A记录，便可得到种子节点的IP地址。</p>\n<pre><code class="lang-erlang">seeders() -&gt;\n    [&quot;seed.bitcoinsv.io&quot;,\n     &quot;seed.cascharia.com&quot;,\n     &quot;seed.satoshisvision.network&quot;\n    ].\n\nseed_nodes() -&gt;\n    L = seeders(),\n    lists:flatten([dnslookup(D) || D &lt;- L]).\n</code></pre>\n<p>运行结果：</p>\n<p><img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554652822504-ee5435ac-efe0-438d-b298-a455d897a173.png#align=left&amp;display=inline&amp;height=283&amp;name=image.png&amp;originHeight=566&amp;originWidth=512&amp;size=81865&amp;status=done&amp;width=256" alt="image.png"></p>\n<blockquote>\n<p>©️OWAF</p>\n</blockquote>\n',
		contents: [
			{
				heading: '获取种子节点的IP',
				level: '1',
				link: '-ip'
			}
		]
	},
	teaser: {
		doc: '比特币网络是开放的，理论上一个节点只要符合比特币的共识协议，就可以参与到网络中。为了更深入理解比特币的共识协议，也是为在比特币上做更多的应用打基础，我们决定实现一个简单的可使用的比特币节点，在实现完成后，代码会以MIT协议开源在Github上。',
		$image_type: 'image',
		image: '/remote/direct_uploads/1554993188_image.png',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '<p>比特币网络是开放的，理论上一个节点只要符合比特币的共识协议，就可以参与到网络中。为了更深入理解比特币的共识协议，也是为在比特币上做更多的应用打基础，我们决定实现一个简单的可使用的比特币节点，在实现完成后，代码会以MIT协议开源在Github上。</p>\n',
			contents: []
		}
	},
	meta: {
		last_edited: 1554993380
	}
})