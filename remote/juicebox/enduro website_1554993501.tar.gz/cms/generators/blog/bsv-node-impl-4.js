({
	title: 'BSV节点实现日志（4）',
	$date_value: '2019-04-07',
	$date_type: 'date',
	date: 'Sunday, 07 April, 2019',
	published: true,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '今天实现的两个指令都是很早期就存在于比特币代码中的，是基础的功能。\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554863105565-3f0335e8-b9f7-4bf7-90d0-d9f38c281bba.png#align=left&display=inline&height=639&name=image.png&originHeight=1278&originWidth=1838&size=529856&status=done&width=919)\n\n# getheaders\n\n2010年12月，比特币[代码中](https://github.com/bitcoin-sv/bitcoin-sv/commit/f03304a9c79a6cc6096ed501ad38702fd012e7f7#diff-118fcbaaba162ba17933c7893247df3aR2438)添加了 getheaders 指令，作用是告知对方自己已知的最新的一些区块哈希，让对方返回更后面的区块的区块头。这一指令在spv节点中十分有用，因为spv节点在同步时，只需要下载区块头的数据，而不需要完整区块。\n\n构造getheaders指令：\n```erlang\ngetheaders_msg(Locators) ->\n    N = varint(length(Locators)),\n    HL = << <<Hash/bytes>> || Hash <- Locators >>,\n    make_message(getheaders, <<?PROTOCOL_VERSION:32/little, N/bytes, HL/bytes, 0:(32*8)>>).\n```\n\n而节点现在还没有任何区块数据，于是我往getheaders指令里面填了创世区块的hash：\n```erlang\nsend_message(Socket, getheaders_msg([?GENESIS]));\n```\n\n结果就是，对方节点愣了几秒中，给我回复了一大串的数据，应该是一些区块头的数据，具体明天再分析。\n\n\n# inv\n\n与其它节点建立连接之后，收到最多的就是inv消息，内容大多是最新的交易的哈希。通常节点在收到交易后，验证合法，就会使用inv指令对 tx hash 进行Relay(传播）。\n\n收到的其中一个inv：\n```erlang\n[remote] inv\n#{inventory =>\n      [{tx,<<183,201,175,128,246,14,231,237,227,231,173,240,248,79,178,189,\n             177,93,60,226,69,190,42,221,161,247,73,61,44,173,27,126>>}]}\n```\n\n转换成大端十六进制字符串的格式就是： \'7e1bad2c3d49f7a1dd2abe45e23c5db1bdb24ff8f0ade7e3ede70ef680afc9b7\'\n\n\n> ©️OWAF',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<p>今天实现的两个指令都是很早期就存在于比特币代码中的，是基础的功能。\n<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554863105565-3f0335e8-b9f7-4bf7-90d0-d9f38c281bba.png#align=left&amp;display=inline&amp;height=639&amp;name=image.png&amp;originHeight=1278&amp;originWidth=1838&amp;size=529856&amp;status=done&amp;width=919" alt="image.png"></p>\n<h1 id="getheaders">getheaders</h1>\n<p>2010年12月，比特币<a href="https://github.com/bitcoin-sv/bitcoin-sv/commit/f03304a9c79a6cc6096ed501ad38702fd012e7f7#diff-118fcbaaba162ba17933c7893247df3aR2438">代码中</a>添加了 getheaders 指令，作用是告知对方自己已知的最新的一些区块哈希，让对方返回更后面的区块的区块头。这一指令在spv节点中十分有用，因为spv节点在同步时，只需要下载区块头的数据，而不需要完整区块。</p>\n<p>构造getheaders指令：</p>\n<pre><code class="lang-erlang">getheaders_msg(Locators) -&gt;\n    N = varint(length(Locators)),\n    HL = &lt;&lt; &lt;&lt;Hash/bytes&gt;&gt; || Hash &lt;- Locators &gt;&gt;,\n    make_message(getheaders, &lt;&lt;?PROTOCOL_VERSION:32/little, N/bytes, HL/bytes, 0:(32*8)&gt;&gt;).\n</code></pre>\n<p>而节点现在还没有任何区块数据，于是我往getheaders指令里面填了创世区块的hash：</p>\n<pre><code class="lang-erlang">send_message(Socket, getheaders_msg([?GENESIS]));\n</code></pre>\n<p>结果就是，对方节点愣了几秒中，给我回复了一大串的数据，应该是一些区块头的数据，具体明天再分析。</p>\n<h1 id="inv">inv</h1>\n<p>与其它节点建立连接之后，收到最多的就是inv消息，内容大多是最新的交易的哈希。通常节点在收到交易后，验证合法，就会使用inv指令对 tx hash 进行Relay(传播）。</p>\n<p>收到的其中一个inv：</p>\n<pre><code class="lang-erlang">[remote] inv\n#{inventory =&gt;\n      [{tx,&lt;&lt;183,201,175,128,246,14,231,237,227,231,173,240,248,79,178,189,\n             177,93,60,226,69,190,42,221,161,247,73,61,44,173,27,126&gt;&gt;}]}\n</code></pre>\n<p>转换成大端十六进制字符串的格式就是： &#39;7e1bad2c3d49f7a1dd2abe45e23c5db1bdb24ff8f0ade7e3ede70ef680afc9b7&#39;</p>\n<blockquote>\n<p>©️OWAF</p>\n</blockquote>\n',
		contents: [
			{
				heading: 'getheaders',
				level: '1',
				link: 'getheaders'
			},
			{
				heading: 'inv',
				level: '1',
				link: 'inv'
			}
		]
	},
	teaser: {
		doc: '2010年12月，比特币添加了 getheaders 指令，作用是告知对方自己已知的最新的一些区块哈希，让对方返回更后面的区块的区块头。这一指令在spv节点中十分有用，因为spv节点在同步时，只需要下载区块头的数据，而不需要完整区块。',
		$image_type: 'image',
		image: '/remote/direct_uploads/1554988443_image.png',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '<p>2010年12月，比特币添加了 getheaders 指令，作用是告知对方自己已知的最新的一些区块哈希，让对方返回更后面的区块的区块头。这一指令在spv节点中十分有用，因为spv节点在同步时，只需要下载区块头的数据，而不需要完整区块。</p>\n',
			contents: []
		}
	},
	meta: {
		last_edited: 1554993347
	}
})