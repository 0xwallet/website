({
	title: 'BSV节点实现日志（2）',
	$date_value: '2019-04-01',
	$date_type: 'date',
	date: 'Monday, 01 April, 2019',
	published: true,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '本篇我们将向bsv节点发送version指令。\n\n\n# 消失的 关注/发布 系统\n比特币目前的p2p协议已经和中本聪的设计有了比较大的不同。在中本聪消失时，留下了未完成的 subscribe/publish 系统。关注/广播 是一种非常高效的消息传播模式，在源代码的注释中，中本聪写道：\n\n> With 100,000 nodes, if senders broadcast to 1000 random nodes and receivers\n> subscribe to 1000 random nodes, 99.995% (1 - 0.99^1000) of messages will get through.\n\n\n> 设有10万个节点，如果发送者广播给随机的1000个节点，而接收者关注了随机的1000个节点，那么消息被收到的可能性是99.995% （1-0.99^1000)。\n\n\n然而在2012年，这一未完成的特性没有被实现，而是被删除了。在更早些时候，[中本聪回复Mike的信](https://nakamotostudies.org/uncategorized/hearn-and-satoshi-correspondence-part-4/)中，关于未完成的pub/sub，他提到：\n\n> I was trying to implement an eBay style marketplace built in to the client. Publish/subscribe would be used for broadcasting product offers and ratings/reviews. Your reviews would be weighted by the blocks you’ve generated. I rightly abandoned it in favour of JSON-RPC, so other authors could implement it externally. The publish/subscribe “meet in the middle” mechanism was an interesting concept, but nothing remains that uses it.\n\n\n也就是说pub/sub的机制可以在外部通过JSON-RPC来实现。\n\n\n# 消息构造\n在2010年5月，0.2.9版本的比特币代码中，修改了节点通信协议的格式，添加了checksum，也就是哈希校验，沿用至今。\n\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554696930697-c7b04cb1-cb63-45aa-9d57-368b6254c984.png#align=left&display=inline&height=134&name=image.png&originHeight=474&originWidth=1764&size=993507&status=done&width=500)<br />节点之间通信的消息结构。\n\n```erlang\n%% 将消息解构\nextract(<<?MAGIC:32/big, Command:12/bytes, Size:32/little-integer, \n          Checksum:4/bytes, Payload:Size/bytes, _Rest/bytes>>) ->\n    Checksum = get_checksum(Payload),\n    {ok, Command, Payload}.\n```\n\n\n<a name="7bf8490f"></a>\n# Version 指令\n![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554710007304-1773a0b6-7d3b-4d0e-b167-614aa7414624.png#align=left&display=inline&height=174&name=image.png&originHeight=500&originWidth=1438&size=926560&status=done&width=500)<br />Version 指令的结构。\n\n```erlang\n%% 构造一个version指令\nversion_msg() ->\n    Services = <<1, 0:(7*8)>>,\n    Timestamp = get_timestamp(),\n    Addr_recv = <<Services/binary, 0:(10*8), 16#FF, 16#FF, 0, 0, 0, 0, 0, 0>>,\n    Addr_from = <<Services/binary, 0:(10*8), 16#FF, 16#FF, 0, 0, 0, 0, 0, 0>>,\n    Nonce = crypto:strong_rand_bytes(8),\n    User_agent = varstr(<<"\n/IS THIS A VALID USER AGNET?/">>),\n    Strat_height = 0,\n    Payload = <<?PROTOCOL_VERSION:32/little, \n                Services/binary, \n                Timestamp:64/little, \n                Addr_recv/binary,\n                Addr_from/binary, \n                Nonce/binary, \n                User_agent/binary, \n                Strat_height:32/little\n              >>,\n    make_message(version, Payload).\n```\n\n当节点接收到version指令时，首先对其进行解析，然后判断对方的版本是否和自己兼容。\n\n尝试将 `PROTOCOL_VERSION` 设置成 1234， bsv的节点回复是：Version must be 31800 or greater。 \n\n查看了 bitcoin-sv 的代码，可以看到在 31800 版本，引入了 `getheaders` 指令。并且不再支持更低版本的节点。\n\n```cpp\n//! In this version, \'getheaders\' was introduced.\nstatic const int GETHEADERS_VERSION = 31800;\n\n//! disconnect from peers older than this proto version\nstatic const int MIN_PEER_PROTO_VERSION = GETHEADERS_VERSION;\n```\n\n\n# 运行\n\n昨天，我们已经得到了一些sv节点的ip地址，尝试与其中一个进行连接，并发送构造好的version指令（版本设置成31800）。可以收到回复，内容是对方的version信息。注意到回复的内容我们还没有完全解析好。<br />![image.png](https://cdn.nlark.com/yuque/0/2019/png/308289/1554710932731-f65665fa-961f-4f54-95cd-630ee5f92734.png#align=left&display=inline&height=46&name=image.png&originHeight=118&originWidth=1286&size=30213&status=done&width=500)\n\n\n> ©️OWAF',
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<p>本篇我们将向bsv节点发送version指令。</p>\n<h1 id="-">消失的 关注/发布 系统</h1>\n<p>比特币目前的p2p协议已经和中本聪的设计有了比较大的不同。在中本聪消失时，留下了未完成的 subscribe/publish 系统。关注/广播 是一种非常高效的消息传播模式，在源代码的注释中，中本聪写道：</p>\n<blockquote>\n<p>With 100,000 nodes, if senders broadcast to 1000 random nodes and receivers\nsubscribe to 1000 random nodes, 99.995% (1 - 0.99^1000) of messages will get through.</p>\n</blockquote>\n<blockquote>\n<p>设有10万个节点，如果发送者广播给随机的1000个节点，而接收者关注了随机的1000个节点，那么消息被收到的可能性是99.995% （1-0.99^1000)。</p>\n</blockquote>\n<p>然而在2012年，这一未完成的特性没有被实现，而是被删除了。在更早些时候，<a href="https://nakamotostudies.org/uncategorized/hearn-and-satoshi-correspondence-part-4/">中本聪回复Mike的信</a>中，关于未完成的pub/sub，他提到：</p>\n<blockquote>\n<p>I was trying to implement an eBay style marketplace built in to the client. Publish/subscribe would be used for broadcasting product offers and ratings/reviews. Your reviews would be weighted by the blocks you’ve generated. I rightly abandoned it in favour of JSON-RPC, so other authors could implement it externally. The publish/subscribe “meet in the middle” mechanism was an interesting concept, but nothing remains that uses it.</p>\n</blockquote>\n<p>也就是说pub/sub的机制可以在外部通过JSON-RPC来实现。</p>\n<h1 id="-">消息构造</h1>\n<p>在2010年5月，0.2.9版本的比特币代码中，修改了节点通信协议的格式，添加了checksum，也就是哈希校验，沿用至今。</p>\n<p><img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554696930697-c7b04cb1-cb63-45aa-9d57-368b6254c984.png#align=left&amp;display=inline&amp;height=134&amp;name=image.png&amp;originHeight=474&amp;originWidth=1764&amp;size=993507&amp;status=done&amp;width=500" alt="image.png">&lt;br /&gt;节点之间通信的消息结构。</p>\n<pre><code class="lang-erlang">%% 将消息解构\nextract(&lt;&lt;?MAGIC:32/big, Command:12/bytes, Size:32/little-integer, \n          Checksum:4/bytes, Payload:Size/bytes, _Rest/bytes&gt;&gt;) -&gt;\n    Checksum = get_checksum(Payload),\n    {ok, Command, Payload}.\n</code></pre>\n<p>&lt;a name=&quot;7bf8490f&quot;&gt;&lt;/a&gt;</p>\n<h1 id="version-">Version 指令</h1>\n<p><img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554710007304-1773a0b6-7d3b-4d0e-b167-614aa7414624.png#align=left&amp;display=inline&amp;height=174&amp;name=image.png&amp;originHeight=500&amp;originWidth=1438&amp;size=926560&amp;status=done&amp;width=500" alt="image.png">&lt;br /&gt;Version 指令的结构。</p>\n<pre><code class="lang-erlang">%% 构造一个version指令\nversion_msg() -&gt;\n    Services = &lt;&lt;1, 0:(7*8)&gt;&gt;,\n    Timestamp = get_timestamp(),\n    Addr_recv = &lt;&lt;Services/binary, 0:(10*8), 16#FF, 16#FF, 0, 0, 0, 0, 0, 0&gt;&gt;,\n    Addr_from = &lt;&lt;Services/binary, 0:(10*8), 16#FF, 16#FF, 0, 0, 0, 0, 0, 0&gt;&gt;,\n    Nonce = crypto:strong_rand_bytes(8),\n    User_agent = varstr(&lt;&lt;&quot;\n/IS THIS A VALID USER AGNET?/&quot;&gt;&gt;),\n    Strat_height = 0,\n    Payload = &lt;&lt;?PROTOCOL_VERSION:32/little, \n                Services/binary, \n                Timestamp:64/little, \n                Addr_recv/binary,\n                Addr_from/binary, \n                Nonce/binary, \n                User_agent/binary, \n                Strat_height:32/little\n              &gt;&gt;,\n    make_message(version, Payload).\n</code></pre>\n<p>当节点接收到version指令时，首先对其进行解析，然后判断对方的版本是否和自己兼容。</p>\n<p>尝试将 <code>PROTOCOL_VERSION</code> 设置成 1234， bsv的节点回复是：Version must be 31800 or greater。 </p>\n<p>查看了 bitcoin-sv 的代码，可以看到在 31800 版本，引入了 <code>getheaders</code> 指令。并且不再支持更低版本的节点。</p>\n<pre><code class="lang-cpp">//! In this version, &#39;getheaders&#39; was introduced.\nstatic const int GETHEADERS_VERSION = 31800;\n\n//! disconnect from peers older than this proto version\nstatic const int MIN_PEER_PROTO_VERSION = GETHEADERS_VERSION;\n</code></pre>\n<h1 id="-">运行</h1>\n<p>昨天，我们已经得到了一些sv节点的ip地址，尝试与其中一个进行连接，并发送构造好的version指令（版本设置成31800）。可以收到回复，内容是对方的version信息。注意到回复的内容我们还没有完全解析好。&lt;br /&gt;<img src="https://cdn.nlark.com/yuque/0/2019/png/308289/1554710932731-f65665fa-961f-4f54-95cd-630ee5f92734.png#align=left&amp;display=inline&amp;height=46&amp;name=image.png&amp;originHeight=118&amp;originWidth=1286&amp;size=30213&amp;status=done&amp;width=500" alt="image.png"></p>\n<blockquote>\n<p>©️OWAF</p>\n</blockquote>\n',
		contents: [
			{
				heading: '消失的 关注/发布 系统',
				level: '1',
				link: '-'
			},
			{
				heading: '消息构造',
				level: '1',
				link: '-'
			},
			{
				heading: 'Version 指令',
				level: '1',
				link: 'version-'
			},
			{
				heading: '运行',
				level: '1',
				link: '-'
			}
		]
	},
	teaser: {
		doc: '比特币目前的p2p协议已经和中本聪的设计有了比较大的不同。在中本聪消失时，留下了未完成的 subscribe/publish 系统。关注/广播 是一种非常高效的消息传播模式，在源代码的注释中，中本聪写道：',
		$image_type: 'image',
		image: '/remote/direct_uploads/1554993014_image.png',
		$abstracted_content_hidden: true,
		abstracted_content: {
			marked_doc: '<p>比特币目前的p2p协议已经和中本聪的设计有了比较大的不同。在中本聪消失时，留下了未完成的 subscribe/publish 系统。关注/广播 是一种非常高效的消息传播模式，在源代码的注释中，中本聪写道：</p>\n',
			contents: []
		}
	},
	meta: {
		last_edited: 1554993374
	}
})