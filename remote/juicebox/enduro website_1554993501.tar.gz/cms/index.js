({
	$background_video_type: 'video',
	background_video: 'https://s3.amazonaws.com/citadel-wordpress-prd102/wp-content/uploads/2016/08/22115057/Citadel_LandingPage_HK_CrossFade-HD.mp4',
	$background_video_poster_type: 'image',
	background_video_poster: '/assets/img/example_files/video_bg.jpg',
	heading: '0xWallet',
	tagline: 'A Bitcoin Wallet with No Limits.',
	features_heading: 'Why 0xWallet ?',
	meta: {
		last_edited: 1552136353
	},
	$heading_cn: '0xWallet',
	$background_video_poster_cn: '/assets/img/example_files/video_bg.jpg',
	$background_video_cn: 'https://s3.amazonaws.com/citadel-wordpress-prd102/wp-content/uploads/2016/08/22115057/Citadel_LandingPage_HK_CrossFade-HD.mp4',
	  $tagline_cn: '无限可能的比特币钱包',
	$features_heading_cn: 'Why 0xWallet ?'
})
