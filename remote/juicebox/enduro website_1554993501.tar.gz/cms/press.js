({
	press_items: [
		  {
			    $file_type: 'image',
			    file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			    $preview_image_type: 'image',
			    preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			    name: 'Media Kit',
			    filetype: 'zip'
		  },
		  {
			    $file_type: 'image',
			    file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			    $preview_image_type: 'image',
			    preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			    name: 'Whitepaper',
			    filetype: 'pdf'
		  },
		  {
			    $file_type: 'image',
			    file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			    $preview_image_type: 'image',
			    preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			    name: '0xCard',
			    filetype: 'pdf'
		  },
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			name: 'Android',
			filetype: 'apk'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			name: 'iOS',
			filetype: 'app'
		},
		{
			$file_type: 'image',
			file: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439572_enduro_e.png',
			$preview_image_type: 'image',
			preview_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1483439993_wb01vp9sr2dl2pam7vi.png',
			name: 'CardOS',
			filetype: 'bin'
		}
	],
	meta: {
		last_edited: 1552133615
	}
})
