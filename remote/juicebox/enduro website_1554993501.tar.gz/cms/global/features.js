({
	features: [
		{
			$icon_type: 'fa',
			icon: 'key',
			title: 'Built for security',
			$text_type: 'textarea',
			text: 'Clicking is lame. With enduro.js, exactly zero clicks are necessary to build the whole project.',
			$linkified_text_hidden: true,
			linkified_text: 'Clicking is lame. With enduro.js, exactly zero clicks are necessary to build the whole project.'
		},
		{
			$icon_type: 'fa',
			icon: 'bank',
			title: 'Backup Safely',
			$text_type: 'textarea',
			text: 'Somebody non-technical will eventually manage content on the website. You might as well provide this person with awesome, beautiful, quick and simple experience.',
			$linkified_text_hidden: true,
			linkified_text: 'Somebody non-technical will eventually manage content on the website. You might as well provide this person with awesome, beautiful, quick and simple experience.'
		},
		{
			$icon_type: 'fa',
			icon: 'credit-card',
			title: 'PoID  and 2FA',
			$text_type: 'textarea',
			text: 'Slow pageloads are the worst. Enduro pregenerates pages to provide the fastest possible response time. Coupled with direct uploading to cdn - can\'t get any faster.',
			$linkified_text_hidden: true,
			linkified_text: 'Slow pageloads are the worst. Enduro pregenerates pages to provide the fastest possible response time. Coupled with direct uploading to cdn - can\'t get any faster.'
		},
		{
			$icon_type: 'fa',
			icon: 'openid',
			title: 'OpenID for crypto',
			$text_type: 'textarea',
			text: '[Sass](/docs/sass) check. [Spritessheet generation](/docs/spritesheet-generator) check. Enduro.js comes with set of build tools to build everything on the server. Forget about ftping built files.',
			$linkified_text_hidden: true,
			linkified_text: '<a href="/docs/sass">Sass</a> check. <a href="/docs/spritesheet-generator">Spritessheet generation</a> check. Enduro.js comes with set of build tools to build everything on the server. Forget about ftping built files.'
		},
		{
			$icon_type: 'fa',
			icon: 'file-code-o',
			title: 'Smart contracts',
			$text_type: 'textarea',
			text: 'Enduro.js comes with browsersync build in and everything hooked up. Change the color in sass file - BOOM - 0.1 seconds later you see the new color in your browser.',
			$linkified_text_hidden: true,
			linkified_text: 'Enduro.js comes with browsersync build in and everything hooked up. Change the color in sass file - BOOM - 0.1 seconds later you see the new color in your browser.'
		},
		{
			$icon_type: 'fa',
			icon: 'bitcoin',
			title: 'PoT tokens',
			$text_type: 'textarea',
			text: 'Enduro.js is built around handlebars. Logiless templates. No way to spagetticode it now.',
			$linkified_text_hidden: true,
			linkified_text: 'Enduro.js is built around handlebars. Logiless templates. No way to spagetticode it now.'
		},
		{
			$icon_type: 'fa',
			icon: 'cloud',
			title: 'Scalable',
			$text_type: 'textarea',
			text: 'Enduro.js projects are self-contained and ready to be web-scaled with push of a button.',
			$linkified_text_hidden: true,
			linkified_text: 'Enduro.js projects are self-contained and ready to be web-scaled with push of a button.'
		},
		{
			$icon_type: 'fa',
			icon: 'code-fork',
			title: 'Open source',
			$text_type: 'textarea',
			text: 'Enduro.js is open-source and free to use. Distributed under the MIT License',
			$linkified_text_hidden: true,
			linkified_text: 'Enduro.js is open-source and free to use. Distributed under the MIT License'
		}
	],
	meta: {
		last_edited: 1534582999
	}
})