({
	users: [
		{
			username: 'gottwik',
			salt: 'b0306f9e001d084bbf0c8888618b30ef',
			hash: '18f39fb5e2cf83229d8a2fe644fda17ab8bd4907a4354cc182454ed9bb0269b3',
			user_created_timestamp: 1470054375378
		},
		{
			username: 'demo',
			tags: [],
			salt: '541270417b5b61df5e5c7b44f12f2206',
			hash: 'b1f0f240ecc517865dd8208c16fb24ee3cd401e0a1c9c5a737da73405d796ae5',
			user_created_timestamp: 1533838450747
		},
		{
			username: 'admin',
			tags: [],
			salt: 'ee0a187033a47344520eb1a17e4ecffc',
			hash: 'da2dabaa76c645ece7df7bfd67c5d5d9bda953d6233cdebe06bda049df5346a4',
			user_created_timestamp: 1552125352105
		}
	],
	meta: {
		last_edited: 1552125352
	}
})